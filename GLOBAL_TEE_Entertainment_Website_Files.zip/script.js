/*
  GLOBAL_TEE Entertainment website settings.
  IMPORTANT: Change whatsappNumber to your WhatsApp number in international format:
  Nigeria example: 2348012345678 (do not include +, spaces or leading 0).
*/
const whatsappNumber = "2340000000000"; // REPLACE with your real WhatsApp number

const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

document.getElementById("year").textContent = new Date().getFullYear();

const bookingForm = document.getElementById("bookingForm");
bookingForm.addEventListener("submit", (event) => {
  event.preventDefault();

  if (whatsappNumber === "2340000000000") {
    document.getElementById("formMessage").textContent =
      "Website setup needed: add your real WhatsApp number in script.js before customers can send booking requests.";
    return;
  }

  const name = document.getElementById("customerName").value.trim();
  const phone = document.getElementById("customerPhone").value.trim();
  const service = document.getElementById("serviceNeeded").value;
  const date = document.getElementById("eventDate").value || "Not specified";
  const location = document.getElementById("eventLocation").value.trim() || "Not specified";
  const details = document.getElementById("eventDetails").value.trim() || "No extra details";

  const message = [
    "Hello GLOBAL_TEE Entertainment! I would like to make a booking.",
    `Name: ${name}`,
    `My phone: ${phone}`,
    `Service: ${service}`,
    `Event date: ${date}`,
    `Location: ${location}`,
    `Event details: ${details}`
  ].join("\n");

  const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
  window.open(url, "_blank", "noopener,noreferrer");
});
