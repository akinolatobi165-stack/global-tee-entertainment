GLOBAL_TEE ENTERTAINMENT WEBSITE
=================================

FILES
-----
index.html   Website content and sections
style.css    Black-and-blue design and mobile layout
script.js    Mobile menu and WhatsApp booking form

BEFORE PUBLISHING
-----------------
1. Open script.js and replace:
   const whatsappNumber = "2340000000000";
   with your own Nigerian WhatsApp number in international format.
   Example format: 2348012345678
   Do not use +, spaces, or the first 0.

2. Confirm the email address in index.html:
   akinolatobi165@gmail.com
   Change it if necessary.

3. Update the About section with your real business story and service area.

4. Replace the sample event calendar entries with real upcoming events.
   They are placeholders, not confirmed events.

5. Replace sample review text with genuine customer reviews and get permission
   before publishing customers' names or photos.

6. Add your own photos:
   - In your GitHub repository, create a folder named images.
   - Upload your own photos into it, for example dj-stage.jpg.
   - In index.html, replace a gallery tile div with:
     <div class="gallery-tile">
       <img src="images/dj-stage.jpg" alt="GLOBAL_TEE DJ performing">
     </div>
   - Add this rule to style.css:
     .gallery-tile img { width:100%; height:100%; object-fit:cover; position:absolute; inset:0; }
   Use photos you own or have permission to use.

7. Add a music mix:
   - Upload your mix to a service such as YouTube, SoundCloud or Audiomack.
   - Add a normal link to your mix in the mixes section.
   Only upload music you have rights or permission to share.

PUBLISH FREE WITH GITHUB PAGES ON ANDROID
-----------------------------------------
A. Open https://github.com/ and sign in.
B. Tap +, then New repository.
C. Repository name: global-tee-entertainment
D. Set repository visibility to Public, then create it.
E. Open the repository and use Add file > Upload files.
F. Upload index.html, style.css and script.js together (not the ZIP file).
G. Commit the changes.
H. Open repository Settings > Pages.
I. Under Build and deployment, choose Deploy from a branch.
J. Choose branch main and folder /(root), then Save.
K. Wait a few minutes, then refresh Settings > Pages.
L. Open the published link shown there. It will usually look like:
   https://YOUR-GITHUB-USERNAME.github.io/global-tee-entertainment/

IMPORTANT
---------
- GitHub Pages can host this static website for free.
- The booking form opens WhatsApp; it does not store bookings in a private database.
- The event calendar and reviews are edited manually in index.html.
- A custom domain such as globaltee...com is separate and may cost money.
- Test the website on your phone after publishing.
